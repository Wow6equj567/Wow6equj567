import React from 'react'

function DrugChecker() {
  return (
    <div>index</div>
  )
}

export default DrugChecker;